# DES Encryption Implementation in C

Instruction:

	- Type make before use to get the executable program
	- Type ./DES -e [source] [key] [destination] to encrypt file
	- Type ./DES -d [source] [key] [destination] to decrypt file